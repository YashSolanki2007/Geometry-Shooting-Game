import pygame 
import math 
import time
import random 
from pygame import mixer

#Game Variables
WIDTH = 800
HEIGHT = 600

#Game Colors
WHITE = (255, 255, 255)

#Initialize pygame 
pygame.init()

#Make the screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Space Shooter Game Made By Yash Solanki")

#Make the display icon 
icon = pygame.image.load("game.png")
pygame.display.set_icon(icon)

#Make the background music
music = mixer.music.load("background.wav")
mixer.music.play(-1)

#Make the player
playerImg = pygame.image.load("war.png")

playerX = 50
playerY = 300

#Make the square enemy
square_enemyImg = pygame.image.load("rectangle.png")

square_enemyX = 800
square_enemyY = 330
square_enemyX_change = -0.4

#Make the triangle
triangle_enemyImg = pygame.image.load("triangle.png")

triangle_enemyX = 980
triangle_enemyY = 330
triangle_enemyX_change = -0.4

#Make the square missile
square_bulletImg = pygame.image.load("rectangle.png")

square_bulletX = 50
square_bulletY = 300
square_bulletX_change = 0.8
square_bullet_state = "ready"

#Make the triangle missile
triangle_bulletImg = pygame.image.load("triangle.png")

triangle_bulletX = 50
triangle_bulletY = 300
triangle_bulletX_change = 0.8
triangle_bullet_state = "ready"

#Make the player score
score_value = 0
font = pygame.font.Font('freesansbold.ttf',60)
textX = 300
textY = 30

#Functions
def player(x, y):
	screen.blit(playerImg, (x, y))

def square_enemy(x, y):
	screen.blit(square_enemyImg, (x, y))

def triangle_enemy(x, y):
	screen.blit(triangle_enemyImg, (x, y))

def show_score(x, y):
	score = font.render("Score :" + str(score_value),True,(0, 0, 0))
	screen.blit(score,(x,y))

def fire_square_bullet(x, y):
	global square_bullet_state 
	square_bullet_state = "fire"
	screen.blit(square_bulletImg, (x + 50, y + 28))

def fire_triangle_bullet(x, y):
	global triangle_bullet_state 
	triangle_bullet_state = "fire"
	screen.blit(triangle_bulletImg, (x + 50, y + 28))

def isCollision(square_enemyX,square_enemyY,square_bulletX,square_bulletY):
	distance = math.sqrt((math.pow(square_enemyX - square_bulletX,2)) + (math.pow(square_enemyY - 
		square_bulletY,2)))
	if distance < 50:
		return True
	else:
		return False

def isCollision_with_triangle(triangle_enemyX,triangle_enemyY,square_bulletX,square_bulletY):
	distance = math.sqrt((math.pow(triangle_enemyX - square_bulletX,2)) + (math.pow(triangle_enemyY - 
		square_bulletY,2)))
	if distance < 50:
		return True
	else:
		return False

def isCollision_with_proper_triangle(triangle_enemyX,triangle_enemyY,triangle_bulletX,triangle_bulletY):
	distance = math.sqrt((math.pow(triangle_enemyX - triangle_bulletX,2)) + (math.pow(triangle_enemyY - 
		triangle_bulletY,2)))
	if distance < 50:
		return True
	else:
		return False

def isCollision_of_triangle_with_square(square_enemyX, square_enemyY, triangle_bulletX, triangle_bulletY):
	distance = math.sqrt((math.pow(square_enemyX - triangle_bulletX,2)) + (math.pow(square_enemyY - 
		triangle_bulletY,2)))
	if distance < 50:
		return True
	else:
		return False

def isCollision_of_square_with_player(playerX, playerY, square_enemyX, square_enemyY):
	distance = math.sqrt((math.pow(playerX+75 - square_enemyX,2)) + (math.pow(playerY - 
		square_enemyY,2)))

	if distance < 50:
		return True

	else:
		return False

def isCollision_of_triangle_with_player(playerX, playerY, triangle_enemyX, triangle_enemyY):
	distance = math.sqrt((math.pow(playerX+75 - triangle_enemyX,2)) + (math.pow(playerY - 
		triangle_enemyY,2)))

	if distance < 50:
		return True 

	else:
		return False

#Main Game Loop
running = True 
while running:
	#Fill the screen
	screen.fill((WHITE))

	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			running = False

		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_q:
				fire_square_bullet(playerX, playerY)

			if event.key == pygame.K_e:
				fire_triangle_bullet(playerX, playerY)

	#Border checking for enemy
	if square_enemyX < 0:
		square_enemyX = 800
		square_enemyX += square_enemyX_change

	if triangle_enemyX < 0:
		triangle_enemyX = 800
		triangle_enemyX += triangle_enemyX_change

	#Move the square bullet
	if square_bulletX > 800:
		square_bulletX = 50
		square_bullet_state = "ready"

	if square_bullet_state is "fire":
		fire_square_bullet(square_bulletX, square_bulletY)
		square_bulletX += square_bulletX_change

	#Move the triangle bullet
	if triangle_bulletX > 800:
		triangle_bulletX = 50
		triangle_bullet_state = "ready"

	if triangle_bullet_state is "fire":
		fire_triangle_bullet(triangle_bulletX, triangle_bulletY)
		triangle_bulletX += triangle_bulletX_change

	#Collisions of square missile
	collision = isCollision(square_enemyX,square_enemyY,square_bulletX,square_bulletY)
	if collision:
		explosion_Sound = mixer.Sound('explosion.wav')
		explosion_Sound.play()
		time.sleep(0.1)
		square_bulletX = 50
		square_bullet_state = "ready"
		score_value += 1
		
		square_enemyX = random.randint(500, 800)

	collision_2 = isCollision(triangle_enemyX,triangle_enemyY,square_bulletX,square_bulletY)
	if collision_2:
		break

	#Collsions of triangle missile
	collision_3 = isCollision_with_triangle(triangle_enemyX,triangle_enemyY,triangle_bulletX,
		triangle_bulletY)
	if collision_3:
		explosion_Sound = mixer.Sound('explosion.wav')
		explosion_Sound.play()
		time.sleep(0.1)
		triangle_bulletX = 50
		triangle_bullet_state = "ready"
		score_value += 1

		triangle_enemyX = random.randint(500, 800)

	collision_4 = isCollision_of_triangle_with_square(square_enemyX, square_enemyY, triangle_bulletX, 
		triangle_bulletY)
	if collision_4:
		break

	collision_5 = isCollision_of_square_with_player(playerX, playerY, square_enemyX, square_enemyY)
	if collision_5:
		break

	collision_6 = isCollision_of_triangle_with_player(playerX, playerY, triangle_enemyX, triangle_enemyY)
	if collision_6:
		break

	#Show the game objetcs
	square_enemyX += square_enemyX_change
	triangle_enemyX += triangle_enemyX_change
	player(playerX, playerY)
	square_enemy(square_enemyX, square_enemyY)
	triangle_enemy(triangle_enemyX, triangle_enemyY)
	show_score(textX, textY)

	#Update the screen
	pygame.display.update()